var Api='';


if(window.location.href.includes("localhost")){
    Api = "http://localhost/event/";
}
else{
    Api="http://softmaticsolution.com/devtolu/"
}



function addCategory(){
//    debugger
    let categoryName = document.getElementById("categoryName").value;
    let checkRequired = true; 

    if(categoryName == ''){
        alert("Kindly Type Category Name")
        checkRequired = false;
    }

    if(checkRequired){
        console.log("insertCheck");
        console.log(categoryName);
        console.log(Api);
    fetch(Api+'backend/addCategory.php', {
        method: 'POST',
        body: JSON.stringify({
            categoryName: categoryName
        }),
        headers: new Headers({
            'Content-Type': 'application/json',
        })

    })
        .then((response) => response.json())
        .then((responseJson) => {
            console.log(responseJson);
            if(responseJson == "Success"){
                alert("Category Successfully Inserted");
                window.location.href = "category.php";
            }
            
        })
        .catch((error) => {
            console.log(error);
            alert("Not Inserted");
            window.location.href = "category.php";

        });
    }
   



}

function eventCategoryDropdown(param){

    fetch(Api+'backend/showCategoryTable.php', {
        method: 'POST',
        body: JSON.stringify({
          
        }),    
        headers: new Headers({
            'content-type': 'application/json',
            'Accept': 'application/json',
        })
    })
    .then((response) => response.json())
    .then((responseJson) =>{
        console.log(responseJson);
        alluserdata = responseJson;
        
        for(var i=0; i<responseJson.length; i++){

            var o = new Option(responseJson[i].c_name, responseJson[i].c_id);
            /// jquerify the DOM object 'o' so we can use the html method
            $(o).html(responseJson[i].c_name);
            $(param).append(o);

        }

       
        
   
      
    })
    .catch((error)=>{
    console.error(error);
      });

}

function addEvent(){
    //    debugger
        var eventName = document.getElementById("eventName").value;
        let eventDesc = document.getElementById("eventDesc").value;
        
        var categoryDrop = document.getElementById("eventCategoryDropdown");
        
        var categoryValue = categoryDrop.options[categoryDrop.selectedIndex].value;
        

        let eventLocation = document.getElementById("eventLocation").value;
        let eventMap = document.getElementById("eventMap").value;
        let eventFees = document.getElementById("eventFees").value;
        let eventDateInput = document.getElementById("eventDateInput").value;
        let eventStartTimeInput = document.getElementById("eventStartTimeInput").value;
        let eventEndTimeInput = document.getElementById("eventEndTimeInput").value;
        let eventWebsite = document.getElementById("eventWebsite").value;

        var PicName = "";
        var picLength = document.getElementById("fileName").files.length;
        if(document.getElementById("fileName").files.length == 0){
            PicName = '';
            
        }   
        else{
            PicName =  eventName+Math.floor(Math.random() * 100000);
        }

    
        
       
        document.getElementById("PicName").value = PicName;


        fetch(Api+'backend/addEvent.php', {
            method: 'POST',
            body: JSON.stringify({
                eventName:eventName,
                eventDesc:eventDesc,
                categoryValue:categoryValue,
                eventLocation:eventLocation,
                eventMap:eventMap,
                eventFees:eventFees,
                eventDateInput:eventDateInput,
                eventStartTimeInput:eventStartTimeInput,
                eventEndTimeInput:eventEndTimeInput,
                eventWebsite:eventWebsite,
                PicName:PicName,
                picLength: picLength,
               
            }),
            headers: new Headers({
                'Content-Type': 'application/json',
            })
    
        })
            .then((response) => response.json())
            .then((responseJson) => {
                console.log(responseJson);

                document.getElementById("PicEventSubmit").click();
                if(responseJson == "Success"){
                    alert("Event Successfully Inserted");
                    window.location.href = "event.php";
                }
                
            })
            .catch((error) => {
                console.log(error);
                alert("Not Inserted");
                window.location.href = "event.php";
    
            });
        
       
    
    
    
    }


function blogin(){

    var username = document.getElementById("username").value;
    var pass = document.getElementById("password").value;

    fetch(Api + 'backend/blogin.php', {
        method: 'POST',
        body: JSON.stringify({
            username: username,
            pass: pass
        }),
        headers: new Headers({
            'Content-Type': 'application/json',
        })
    })
        .then((response) => response.json())
        .then((responseJson) => {
            
           
            if (responseJson === "Wrong Details") {
                alert("Wrong Details");
                window.location.href = "dashboard.php";
            }
            else if(responseJson == "invalid"){
                alert("Invalid Characters");
                window.location.href = "dashboard.php";
            }
            else {
               
                // createCookie("role",responseJson.role,1);
                // createCookie("user",responseJson.u_id,1);
                // createCookie("username",responseJson.name,1);
                // localStorage.setItem("role", responseJson.role);
                // localStorage.setItem("user", responseJson.u_id);
                // localStorage.setItem("username", responseJson.name);

                
                // logStatus('in',responseJson.u_id,responseJson.name);
                window.location.href = "dashboard.php";
            }
           

        })
        .catch((error) => {
            // console.error(error);
            alert('Failed');

            window.location.href = "dashboard.php";
        });
  
   
}
function onLoadFunction(param){

    if(param == "eventPage"){
        document.title = "EVENT";
        eventCategoryDropdown("#eventCategoryDropdown");

    }
    else if(param == "categoryPage"){
        document.title = "CATEGORY";
        categoryTableLoad();
    }
    else if(param == "eventListPage"){
        document.title = "EVENT LIST";
        eventTableLoad();
        eventCategoryDropdown("#seventCategoryDropdown");
    }
    else if(param == "calenderPage"){
        document.title = "CALENDER";
        calenderPageLoad();
    }
    
}

