<?php
error_reporting(0);
// session_start();
include('DBConfig.php');	


$json = file_get_contents('php://input');
 
	 // decoding the received JSON and store into $obj variable.
	 $obj = json_decode($json,true);

	 $username = $obj['username'];
	 $password = $obj['pass'];

	if($proceed){

	$username = strip_tags(mysqli_real_escape_string($con,trim($username)));
	$password = strip_tags(mysqli_real_escape_string($con,trim($password)));

	$username = htmlspecialchars($username);
	$password= htmlspecialchars($password);

	$query = "select * from users where username='".$username."' and pass = '".$password."";
	// $result= $con->query("select * from census_users where username='$username'");


	$tbl = mysqli_query($con,$query);
	if(mysqli_num_rows($tbl)>0){
	

			echo $json;	
		 
	}
	else{
		echo json_encode('Wrong Details');	
	}
}

?>