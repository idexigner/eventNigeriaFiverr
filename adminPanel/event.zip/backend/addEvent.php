<?php 

include 'DBConfig.php';


	$json = file_get_contents('php://input');
 
	 // decoding the received JSON and store into $obj variable.
	 $obj = json_decode($json,true);

     $eventName = htmlspecialchars($obj['eventName']);
     $eventDesc = htmlspecialchars($obj['eventDesc']);
     $categoryValue = htmlspecialchars($obj['categoryValue']);
     $eventLocation = htmlspecialchars($obj['eventLocation']);
     $eventMap = htmlspecialchars($obj['eventMap']);
     $eventFees = htmlspecialchars($obj['eventFees']);
     $eventDateInput = htmlspecialchars($obj['eventDateInput']);
     $eventStartTimeInput = htmlspecialchars($obj['eventStartTimeInput']);
     $eventEndTimeInput = htmlspecialchars($obj['eventEndTimeInput']);
     $eventWebsite = htmlspecialchars($obj['eventWebsite']);
     $PicName = htmlspecialchars($obj['PicName']);
     $picLength = htmlspecialchars($obj['picLength']);
     

    //  $academicStr = strip_tags(mysqli_real_escape_string($con,trim($obj['academicStr'])));
    //  $professionalStr = strip_tags(mysqli_real_escape_string($con,trim($obj['professionalStr'])));
    
    
    $result = $con->query("insert into event(name, description, c_id, location, map_link, fees, date, start_time, end_time, website,image_name,image_length,addToCalender) values ('$eventName','$eventDesc','$categoryValue','$eventLocation','$eventMap','$eventFees','$eventDateInput','$eventStartTimeInput','$eventEndTimeInput','$eventWebsite','$PicName','$picLength','no')");

    // $result = $con->query("insert into event(name, description, c_id, location, map_link, fees, date, start_time, end_time, website) values ('$eventName','$eventDesc','$categoryValue','$eventLocation','$eventMap','$eventFees','$eventDateInput','$eventStartTimeInput','$eventEndTimeInput','$eventWebsite',)");

    if($result){
				echo json_encode("Success");
			}
			else{
			   echo json_encode(mysqli_error($con)); // our query fail 		

                echo "assad";
			}

?>







